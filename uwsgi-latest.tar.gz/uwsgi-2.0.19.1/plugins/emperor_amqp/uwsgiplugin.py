
NAME='emperor_amqp'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['amqp','emperor_amqp']
