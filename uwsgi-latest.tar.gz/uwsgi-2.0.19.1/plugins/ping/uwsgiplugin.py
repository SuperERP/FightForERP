NAME='ping'
CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['ping_plugin']
