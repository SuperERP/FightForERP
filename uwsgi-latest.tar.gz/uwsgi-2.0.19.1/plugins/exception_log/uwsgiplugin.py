NAME='exception_log'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['exception_log']
