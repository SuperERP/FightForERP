NAME='curl_cron'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lcurl']
GCC_LIST = ['curl_cron']
