
NAME='http'
CFLAGS = []
LDFLAGS = []
LIBS = []

REQUIRES = ['corerouter']

GCC_LIST = ['http', 'keepalive', 'https', 'spdy3']
